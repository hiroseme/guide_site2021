<?php
echo "Incorrect Username or Password...";
header("refresh:1; url=login.php");
?>